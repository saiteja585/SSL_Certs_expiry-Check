# SSL_Certs_expiry-Check-
To check SSL certificate Expiry Date and get alert based on warning and critical days.
